﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lesson_10
{
    public delegate void DisplayMessage(string message);
    public delegate int MathOperations();
}
