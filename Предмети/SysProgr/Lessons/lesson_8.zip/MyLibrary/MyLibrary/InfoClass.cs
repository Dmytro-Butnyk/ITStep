﻿namespace MyLibrary
{
    public static class InfoClass
    {
        public static void ShowMessage(string information)
        {
            Console.WriteLine($"Info message: {information}");
        }
    }
}
