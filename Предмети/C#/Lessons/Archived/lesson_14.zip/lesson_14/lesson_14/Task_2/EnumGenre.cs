﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lesson_14.Task_2
{
    public enum Genre { Comedy, Fantasy, Thriller, Drama, ScienceFiction };
}
