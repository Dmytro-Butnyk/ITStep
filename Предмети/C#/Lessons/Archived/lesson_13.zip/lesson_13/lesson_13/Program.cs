﻿// See https://aka.ms/new-console-template for more information
using lesson_13;
using static System.Console;

// task 1 - 3
/*
WriteLine(GenFunc.MinOfThree(2,3,4));
WriteLine(GenFunc.MaxOfThree(2, 3, 4));
WriteLine(GenFunc.SumArray(2, 3, 4));
*/

// task 4
/*
Garage garage = new Garage(new List<Vehicle> 
{
    new Vehicle("Black", "Mercedes", 400),
    new Vehicle("Red", "Mustang", 500),
    new Vehicle("Gray", "Lanos", 150)
});

WriteLine("Vehicles in garage:");
foreach (var it in garage)
{
    WriteLine(it);
}
*/


