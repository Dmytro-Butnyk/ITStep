﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hw_18
{
    public record Fraction
    {
        public int Numerator { get; set; }
        public int Denominator { get; set; }
    }
}
