﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hw_9
{
    public interface IOutput
    {
        void Show();
        void Show(string message);
    }
}
