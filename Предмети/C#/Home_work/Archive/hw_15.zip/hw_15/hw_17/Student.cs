﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hw_17
{
    public record Student(string name, string lastName, uint age, string educationalInstitution);
}
